package com.example.realtimeapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlin.concurrent.thread
import android.widget.TextView
import android.webkit.WebView

class MainActivity : AppCompatActivity() {

    private val client = OkHttpClient()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webView)
        val statusText = findViewById<TextView>(R.id.statusText)

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true

        webView.loadUrl("https://studio--studio-786783784-cb7fe.us-central1.hosted.app/")

        thread {
            while (true) {
                try {
                    val request = Request.Builder()
                        .url("https://studio--studio-786783784-cb7fe.us-central1.hosted.app/")
                        .build()

                    val response = client.newCall(request).execute()
                    val html = response.body?.string()

                    runOnUiThread {
                        statusText.text = "Bağlantı Aktif\nVeri Boyutu: ${html?.length}"
                    }

                    Thread.sleep(5000)

                } catch (e: Exception) {
                    runOnUiThread {
                        statusText.text = "Hata: ${e.message}"
                    }
                }
            }
        }
    }
}
