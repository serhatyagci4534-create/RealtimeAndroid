# Realtime Android App

WasteSense Hub sitesini birebir gösteren Android uygulaması.

## APK Derleme Adımları

### Yöntem 1: Android Studio (Önerilen)
1. Android Studio'yu aç: https://developer.android.com/studio
2. "Open" ile bu klasörü aç
3. Gradle sync otomatik yapılır
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK: `app/build/outputs/apk/debug/app-debug.apk`

### Yöntem 2: Komut Satırı
```bash
# Linux/Mac
chmod +x gradlew
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```
APK çıktısı: `app/build/outputs/apk/debug/app-debug.apk`

## Gereksinimler
- Android Studio Hedgehog veya üzeri
- JDK 17+
- Android SDK 34

## Uygulama Ne Yapıyor?
- WebView ile siteyi birebir açar: https://studio--studio-786783784-cb7fe.us-central1.hosted.app/
- Her 5 saniyede bağlantı durumunu kontrol eder
- Üstte bağlantı durumu + veri boyutunu gösterir
